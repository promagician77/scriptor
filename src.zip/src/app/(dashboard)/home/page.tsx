import Dashboard from '@/views/Dashboard/Dashboard'

const DashboardPage = () => {
  return (
    <div className='flex flex-col justify-center items-center'>
      <Dashboard />
    </div>
  )
}

export default DashboardPage
