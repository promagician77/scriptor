// Next Imports
import type { Metadata } from 'next'

// Component Imports
import About from '@/views/About'

const AboutPage = () => {
  return (
    <div className='flex flex-col justify-center items-center p-6'>
      <About />
    </div>
  )
}

export default AboutPage
