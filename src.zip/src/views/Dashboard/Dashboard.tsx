'use client'

import ProjectCard from '@/views/Dashboard/ProjectCard'
import { useEffect, useState } from 'react'
import CreateProjectModal from '@/views/Dashboard/CreateProjectModal'
import { createClient } from '@configs/supabase'

import { Grid, Typography, Button } from '@mui/material'

import { toast } from 'react-toastify'

export default function Dashboard() {
  const [isModalOpen, setIsModalOpen] = useState(false)
  const [projects, setProjects] = useState<any[]>([])
  const [rerender, setRerender] = useState(false)

  const supabase = createClient();

  useEffect(() => {
    const fetchProjects = async () => {
      const { data, error } = await supabase
        .from('Project')
        .select('*')
      if (error) {
        console.error('Error fetching projects:', error)
      } else {
        setProjects(data)
      }
    }

    fetchProjects()
  }, [rerender])

  const handleCreateProject = async (data: {
    title: string
    genre: string
    tone: string
    concept: string
  }) => {
    // Handle the new project creation here
    const { error } = await supabase
      .from('Project')
      .insert({
        title: data.title,
        genre: data.genre,
        tone: data.tone,
        concept: data.concept
      })

    if (error) {
      toast.error('Error creating project')
    } else {
      toast.success('Project created successfully')
      setRerender(!rerender)
    }

    handleCloseModal()
  }

  const handleCloseModal = () => setIsModalOpen(false)

  const handleProjectUpdate = () => {
    setRerender(!rerender) // Trigger refetch of projects
  }

  return (
    <div className='w-full h-full'>
      <div className='flex justify-between items-center'>
        <Typography variant='h5' color='primary' className='mbe-3'> Projects </Typography>
        <Button variant='contained' color='primary' onClick={() => setIsModalOpen(true)}> Add Project </Button>
      </div>
      <Grid container spacing={2} className='mt-4'>
        {projects.map((project) => (
          <Grid item xs={12} md={4} key={project.id}>
            <ProjectCard 
              title={project.title}
              category={project.genre}
              completionPercentage={50}
              lastUpdated={project.created_at}
              id={project.id}
              onUpdate={handleProjectUpdate}
            />
          </Grid>
        ))}
      </Grid>
      <CreateProjectModal
        open={isModalOpen}
        onClose={handleCloseModal}
        onSubmit={handleCreateProject}
      />
    </div>
  )
}
